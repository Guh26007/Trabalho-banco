# SmartBank IA
Projeto bancário com IA.
Execute frontend/html/index.html e conecte API Express.